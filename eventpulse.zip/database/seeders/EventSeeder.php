<?php

namespace Database\Seeders;

use App\Models\Event;
use App\Models\TicketType;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class EventSeeder extends Seeder
{
    /** Mot de passe du compte vitrine contact@eventpulse.cd */
    public const ORGANIZER_PASSWORD = 'Ksh@EventPulse2026!';

    public function run(): void
    {
        if (app()->environment('production')) {
            $this->command?->error('EventSeeder : exécution interdite en production.');

            return;
        }

        $plainPassword = env('EVENTSEEDER_ORGANIZER_PASSWORD', self::ORGANIZER_PASSWORD);
        $password = Hash::make($plainPassword);

        $organizer = User::updateOrCreate(
            ['email' => 'contact@eventpulse.cd'],
            [
                'name' => 'Event Pulse Kinshasa',
                'password' => $password,
                'role' => 'organizer',
                'phone' => '0812345678',
                'mobile_money_provider' => 'mpesa',
                'bank_account_holder' => 'Event Pulse Kinshasa',
                'bank_name' => 'Rawbank',
                'bank_account_number' => '00012345678901',
                'email_verified_at' => now(),
            ]
        );

        $events = [
            [
                'title' => 'Forum Tech & Innovation — Kinshasa',
                'description' => "Rencontre gratuite pour fondateurs, développeurs et créateurs d'entreprise.\n\nAu programme : keynotes sur l'IA et le Mobile Money, tables rondes avec des mentors locaux, et sessions de networking dans le quartier de la Gombe.\n\nPlaces limitées — réservez votre entrée en ligne.",
                'location' => 'Kinshasa — Gombe, Centre Kongo',
                'category' => 'tech',
                'event_date' => now()->addDays(10)->setTime(9, 0),
                'placement_mode' => Event::PLACEMENT_STANDING,
                'accepted_payment_methods' => [],
                'types' => [
                    ['name' => 'Entrée Gratuite', 'price' => 0, 'quantity' => 200],
                ],
            ],
            [
                'title' => 'Conférence Entrepreneuriat Jeunes — Kinshasa',
                'description' => "Journée gratuite dédiée aux jeunes entrepreneurs de Kinshasa et du Kongo.\n\nInterventions sur le financement, le marketing digital et la gestion d'équipe. Remise de attestations de participation sur place.\n\nInscription obligatoire via Event Pulse.",
                'location' => 'Kinshasa — Lingwala, Institut Français',
                'category' => 'conference',
                'event_date' => now()->addDays(18)->setTime(14, 0),
                'placement_mode' => Event::PLACEMENT_STANDING,
                'accepted_payment_methods' => [],
                'types' => [
                    ['name' => 'Accès Général', 'price' => 0, 'quantity' => 150],
                ],
            ],
            [
                'title' => 'Concert Live — Nuit Rumba Kin',
                'description' => "Soirée payante avec les meilleurs artistes rumba congolaise et afrobeat.\n\nScène live, sound system professionnel et espace VIP. Paiement par Mobile Money ou espèces à l'entrée après réservation en ligne.\n\nNe manquez pas l'événement musical de la saison à Kinshasa !",
                'location' => 'Kinshasa — Bandalungwa, Stade Tata Raphaël',
                'category' => 'music',
                'event_date' => now()->addDays(25)->setTime(20, 0),
                'placement_mode' => Event::PLACEMENT_STANDING,
                'accepted_payment_methods' => ['mobile_money', 'cash'],
                'payment_method' => 'mobile_money',
                'types' => [
                    ['name' => 'Standard', 'price' => 15000, 'quantity' => 500],
                    ['name' => 'VIP', 'price' => 35000, 'quantity' => 80],
                ],
            ],
        ];

        foreach ($events as $data) {
            $this->seedEvent($organizer, $data);
        }

        $this->command?->info('EventSeeder : contact@eventpulse.cd + 3 événements vitrines Kinshasa.');
        $this->command?->comment('Mot de passe : variable EVENTSEEDER_ORGANIZER_PASSWORD dans .env (local uniquement).');
    }

    /**
     * @param  array<string, mixed>  $data
     */
    private function seedEvent(User $organizer, array $data): Event
    {
        $types = $data['types'];
        unset($data['types']);

        $slug = Str::slug($data['title']);
        $capacity = (int) collect($types)->sum('quantity');
        $minPrice = (float) collect($types)->min('price');
        $isFree = Event::ticketTypesAreFree($types);

        $event = Event::updateOrCreate(
            ['slug' => $slug],
            array_merge([
                'user_id' => $organizer->id,
                'slug' => $slug,
                'capacity' => $capacity,
                'price' => $minPrice,
                'status' => 'published',
                'is_paid' => false,
                'publication_fee' => Event::publicationFee(),
                'paid_at' => null,
                'placement_mode' => Event::PLACEMENT_STANDING,
                'accepted_payment_methods' => $isFree ? [] : ($data['accepted_payment_methods'] ?? ['mobile_money', 'cash']),
            ], $data)
        );

        $event->ticketTypes()->delete();

        foreach ($types as $type) {
            $event->ticketTypes()->create([
                'name' => $type['name'],
                'price' => $type['price'],
                'quantity' => (int) $type['quantity'],
                'is_seated' => false,
            ]);
        }

        return $event->fresh('ticketTypes');
    }
}
