<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Comptes démo (password) — jamais en production.
        if (! app()->environment('production')) {
            $this->call([
                EventPulseDemoSeeder::class,
                EventSeeder::class,
            ]);
        }
    }
}
