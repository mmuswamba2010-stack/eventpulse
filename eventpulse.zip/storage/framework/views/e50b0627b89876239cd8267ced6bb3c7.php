<?php if($events->isEmpty()): ?>
    <div class="ep-card px-6 py-16 text-center" data-total="0">
        <img src="<?php echo e(asset('images/brand/mark.svg')); ?>" alt="" class="h-12 w-12 mx-auto mb-4 opacity-30">
        <?php if(! empty($search) || ! empty($category)): ?>
            <p class="font-display text-lg font-semibold text-charcoal">Aucun événement trouvé</p>
            <p class="text-sm text-frost mt-2">
                <a href="<?php echo e(route('events.index')); ?>" class="ep-btn-outline text-sm mt-4 no-underline">Voir tout le catalogue</a>
            </p>
        <?php else: ?>
            <p class="font-display text-lg font-semibold text-charcoal">Rien pour l'instant</p>
            <p class="text-sm text-frost mt-2">De nouveaux événements arrivent bientôt.</p>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div data-total="<?php echo e($events->total()); ?>">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal07bdbe031a4c57e4cd3488994f94e999 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal07bdbe031a4c57e4cd3488994f94e999 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.event-card','data' => ['event' => $event]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('event-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['event' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal07bdbe031a4c57e4cd3488994f94e999)): ?>
<?php $attributes = $__attributesOriginal07bdbe031a4c57e4cd3488994f94e999; ?>
<?php unset($__attributesOriginal07bdbe031a4c57e4cd3488994f94e999); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal07bdbe031a4c57e4cd3488994f94e999)): ?>
<?php $component = $__componentOriginal07bdbe031a4c57e4cd3488994f94e999; ?>
<?php unset($__componentOriginal07bdbe031a4c57e4cd3488994f94e999); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-10">
            <?php echo e($events->links()); ?>

        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\User\event-pulse\resources\views/events/_grid.blade.php ENDPATH**/ ?>