<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php
        $filterParams = fn (?string $cat = null, ?string $whenVal = null) => array_filter([
            'search' => $search ?: null,
            'category' => $cat,
            'when' => $whenVal ?? ($when ?: null),
        ]);
        $gridParams = array_filter([
            'search' => $search ?: null,
            'category' => $category ?: null,
            'when' => $when ?: null,
        ]);
        $sectionTitle = match (true) {
            (bool) $search => 'Résultats de recherche',
            (bool) $category => \App\Models\Event::CATEGORIES[$category] ?? 'Événements',
            $when === 'today' => 'Aujourd\'hui',
            $when === 'weekend' => 'Ce week-end',
            default => 'Événements à ne pas manquer',
        };
    ?>

    <div class="min-h-screen bg-white"
         x-data="eventCatalog({
            gridUrl: <?php echo \Illuminate\Support\Js::from(route('events.grid', $gridParams))->toHtml() ?>,
            page: <?php echo \Illuminate\Support\Js::from(max(1, (int) request('page', 1)))->toHtml() ?>,
            initialTotal: <?php echo \Illuminate\Support\Js::from($events->total())->toHtml() ?>,
         })"
         x-init="hydrate()">

        
        <section id="hero-search" class="relative overflow-hidden bg-white border-b border-charcoal/[0.05]">
            <div class="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
                <div class="absolute -top-28 left-1/2 -translate-x-1/2">
                    <div class="h-[min(500px,78vw)] w-[min(900px,115vw)] rounded-full bg-gradient-to-b from-coral-muted/75 via-coral-muted/35 to-transparent blur-3xl"></div>
                </div>
                <div class="absolute top-6 left-1/2 -translate-x-1/2 h-[min(340px,52vw)] w-[min(620px,88vw)] rounded-full bg-coral-muted/25 blur-2xl"></div>
            </div>
            <div class="pointer-events-none absolute inset-x-0 bottom-0 h-16 bg-gradient-to-b from-transparent to-white" aria-hidden="true"></div>

            <div class="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20 text-center">
                <h1 class="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-charcoal leading-tight">
                    Vivez des expériences<br class="hidden sm:inline">
                    <span class="bg-gradient-to-r from-coral to-brand-700 bg-clip-text text-transparent">inoubliables.</span>
                </h1>
                <p class="mt-4 text-base sm:text-lg text-frost max-w-2xl mx-auto leading-relaxed">
                    Découvrez et réservez les meilleures événements autour de vous.
                    <br>
                    Concerts, conférences, festivals, spectacles, et bien plus encore.
                </p>

                <form method="GET" action="<?php echo e(route('events.index')); ?>" class="mt-8 max-w-xl mx-auto w-full">
                    <?php if($category): ?>
                        <input type="hidden" name="category" value="<?php echo e($category); ?>">
                    <?php endif; ?>
                    <label for="catalog-search" class="sr-only">Rechercher</label>
                    <div class="flex items-center gap-2 rounded-full border border-charcoal/[0.1] bg-white shadow-sm pl-5 pr-1.5 py-1.5 focus-within:ring-2 focus-within:ring-coral/20">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'magnifying-glass','class' => 'w-5 h-5 text-frost shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'magnifying-glass','class' => 'w-5 h-5 text-frost shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        <input id="catalog-search" type="text" name="search"
                            placeholder="Concert, conférence, lieu…"
                            class="flex-1 min-w-0 bg-transparent border-0 focus:ring-0 text-sm sm:text-base text-charcoal placeholder:text-frost py-2.5 sm:py-3"
                            value="<?php echo e($search ?? ''); ?>">
                        <button type="submit" class="ep-btn rounded-full px-5 sm:px-7 py-2.5 sm:py-3 text-sm shrink-0">
                            Rechercher
                        </button>
                    </div>
                </form>

                <ul class="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-3 text-sm text-frost">
                    <li class="inline-flex items-center gap-2">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'shield-check','class' => 'w-5 h-5 text-coral shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'shield-check','class' => 'w-5 h-5 text-coral shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        Paiement sécurisé
                    </li>
                    <li class="inline-flex items-center gap-2">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'ticket','class' => 'w-5 h-5 text-coral shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'ticket','class' => 'w-5 h-5 text-coral shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        Billet électronique
                    </li>
                </ul>
            </div>
        </section>

        
        <section id="categories" class="bg-cream/50 py-12 sm:py-16">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center mb-8 sm:mb-10">
                    <h2 class="text-xl sm:text-2xl font-bold text-charcoal">Parcourir par catégorie</h2>
                    <p class="mt-2 text-sm text-frost">Trouvez l'événement qui vous correspond</p>
                </div>

                <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-5">
                    <?php $__currentLoopData = \App\Models\Event::CATEGORIES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key === 'other') continue; ?>
                        <?php if (isset($component)) { $__componentOriginal7f325559a12e2477115e949a50505fef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f325559a12e2477115e949a50505fef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.category-tile','data' => ['category' => $key,'label' => $label,'count' => $categoryCounts[$key] ?? 0,'active' => $category === $key,'href' => route('events.index', $filterParams($key))]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('category-tile'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['category' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($key),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($label),'count' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($categoryCounts[$key] ?? 0),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category === $key),'href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('events.index', $filterParams($key)))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f325559a12e2477115e949a50505fef)): ?>
<?php $attributes = $__attributesOriginal7f325559a12e2477115e949a50505fef; ?>
<?php unset($__attributesOriginal7f325559a12e2477115e949a50505fef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f325559a12e2477115e949a50505fef)): ?>
<?php $component = $__componentOriginal7f325559a12e2477115e949a50505fef; ?>
<?php unset($__componentOriginal7f325559a12e2477115e949a50505fef); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('events.index')); ?>#events"
                       class="group flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-charcoal/15 bg-white p-5 sm:p-6 text-center no-underline transition hover:border-coral/40 hover:bg-coral-muted/30">
                        <span class="flex h-12 w-12 items-center justify-center rounded-xl bg-charcoal/[0.04] text-charcoal group-hover:bg-coral group-hover:text-white transition">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'plus','class' => 'h-6 w-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus','class' => 'h-6 w-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </span>
                        <span class="text-sm font-semibold text-charcoal">Voir plus</span>
                        <span class="text-xs text-frost">Tout le catalogue</span>
                    </a>
                </div>
            </div>
        </section>

        
        <section id="events" class="bg-white py-12 sm:py-14">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex flex-wrap items-end justify-between gap-3 mb-10">
                    <div>
                        <h2 class="text-xl sm:text-2xl font-bold text-charcoal"><?php echo e($sectionTitle); ?></h2>
                        <?php if($search): ?>
                            <p class="mt-1 text-sm text-frost">« <?php echo e($search); ?> »</p>
                        <?php elseif(! $category): ?>
                            <p class="mt-1 text-sm text-frost">Les meilleures expériences près de chez vous</p>
                        <?php endif; ?>
                        <?php if($search || $category): ?>
                            <a href="<?php echo e(route('events.index')); ?>"
                               class="inline-block mt-2 text-sm font-medium text-coral hover:text-brand-700 no-underline">
                                Effacer les filtres
                            </a>
                        <?php endif; ?>
                    </div>
                    <p class="text-sm text-frost">
                        <span x-text="total" class="font-semibold text-charcoal"><?php echo e($events->total()); ?></span>
                        événement(s)
                    </p>
                </div>

                <div x-show="loading" x-cloak class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8" aria-busy="true">
                    <?php for($i = 0; $i < 8; $i++): ?>
                        <?php if (isset($component)) { $__componentOriginal465dac723dddd36c114d6ce098454144 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal465dac723dddd36c114d6ce098454144 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.event-card-skeleton','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('event-card-skeleton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal465dac723dddd36c114d6ce098454144)): ?>
<?php $attributes = $__attributesOriginal465dac723dddd36c114d6ce098454144; ?>
<?php unset($__attributesOriginal465dac723dddd36c114d6ce098454144); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal465dac723dddd36c114d6ce098454144)): ?>
<?php $component = $__componentOriginal465dac723dddd36c114d6ce098454144; ?>
<?php unset($__componentOriginal465dac723dddd36c114d6ce098454144); ?>
<?php endif; ?>
                    <?php endfor; ?>
                </div>

                <div x-show="!loading" x-ref="grid">
                    <?php echo $__env->make('events._grid', ['events' => $events, 'search' => $search, 'category' => $category], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>
        </section>

        
        <section class="border-t border-charcoal/[0.06] bg-cream/40 py-12 sm:py-14">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                    <div class="text-center sm:text-left">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-coral-muted text-coral mb-3">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'bolt','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bolt','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </span>
                        <p class="font-semibold text-charcoal">Réservation rapide</p>
                        <p class="mt-1 text-sm text-frost leading-relaxed">Billets confirmés en quelques secondes.</p>
                    </div>
                    <div class="text-center sm:text-left">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-coral-muted text-coral mb-3">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'shield-check','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'shield-check','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </span>
                        <p class="font-semibold text-charcoal">Paiement sécurisé</p>
                        <p class="mt-1 text-sm text-frost leading-relaxed">Mobile Money, carte ou espèces.</p>
                    </div>
                    <div class="text-center sm:text-left">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-coral-muted text-coral mb-3">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'device-phone-mobile','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'device-phone-mobile','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </span>
                        <p class="font-semibold text-charcoal">Billet mobile</p>
                        <p class="mt-1 text-sm text-frost leading-relaxed">QR code sur votre téléphone, prêt à scanner.</p>
                    </div>
                    <div class="text-center sm:text-left">
                        <span class="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-coral-muted text-coral mb-3">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'phone','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'phone','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </span>
                        <p class="font-semibold text-charcoal">Support 24/7</p>
                        <p class="mt-1 text-sm text-frost leading-relaxed">Une équipe disponible pour vous aider.</p>
                    </div>
                </div>
            </div>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\User\event-pulse\resources\views/events/index.blade.php ENDPATH**/ ?>