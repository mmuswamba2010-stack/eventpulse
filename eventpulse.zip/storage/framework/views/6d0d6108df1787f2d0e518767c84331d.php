<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'full',
    'tone' => 'dark',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'full',
    'tone' => 'dark',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $onDark = $tone === 'light';
?>

<a <?php echo e($attributes->merge(['href' => route('events.index'), 'class' => 'inline-flex items-center gap-2.5 group shrink-0'])); ?>>
    <img src="<?php echo e(asset('images/brand/mark.svg')); ?>" alt=""
         class="h-9 w-9 shrink-0 transition group-hover:scale-[1.03]"
         width="36" height="36">
    <?php if($variant === 'full'): ?>
        <span class="ep-logo-text notranslate" translate="no">
            <span class="<?php echo e($onDark ? 'text-frost' : 'text-frost'); ?>">Event</span>
            <span class="<?php echo e($onDark ? 'text-white' : 'text-charcoal'); ?>"> Pulse</span>
        </span>
    <?php endif; ?>
</a>
<?php /**PATH C:\Users\User\event-pulse\resources\views\components\brand-logo.blade.php ENDPATH**/ ?>