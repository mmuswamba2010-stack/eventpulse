<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'category',
    'label',
    'active' => false,
    'tone' => 'light',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'category',
    'label',
    'active' => false,
    'tone' => 'light',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $onDark = $tone === 'dark';
    $icon = match ($category) {
        'music' => 'star',
        'tech' => 'chart-bar',
        'art' => 'photo',
        'sport' => 'bolt',
        'conference' => 'building-storefront',
        default => 'ticket',
    };
?>

<a <?php echo e($attributes->merge([
    'class' => 'group flex flex-col items-center gap-2.5 w-[4.5rem] sm:w-20 shrink-0 no-underline',
])); ?>>
    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full border transition shadow-sm',
        'bg-white border-coral ring-2 ring-coral/30' => $active && $onDark,
        'bg-white/10 border-white/20 group-hover:bg-white/15 group-hover:border-white/30' => ! $active && $onDark,
        'bg-white border-coral ring-2 ring-coral/20' => $active && ! $onDark,
        'bg-white border-charcoal/10 group-hover:border-charcoal/25 group-hover:shadow-md' => ! $active && ! $onDark,
    ]); ?>">
        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => $icon,'class' => \Illuminate\Support\Arr::toCssClasses([
            'w-6 h-6',
            'text-coral' => $active,
            'text-white/80 group-hover:text-white' => ! $active && $onDark,
            'text-charcoal/70 group-hover:text-charcoal' => ! $active && ! $onDark,
        ])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon),'class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(\Illuminate\Support\Arr::toCssClasses([
            'w-6 h-6',
            'text-coral' => $active,
            'text-white/80 group-hover:text-white' => ! $active && $onDark,
            'text-charcoal/70 group-hover:text-charcoal' => ! $active && ! $onDark,
        ]))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
    </span>
    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'text-[11px] sm:text-xs font-medium text-center leading-tight',
        'text-white font-semibold' => $active && $onDark,
        'text-frost group-hover:text-white' => ! $active && $onDark,
        'text-charcoal font-semibold' => $active && ! $onDark,
        'text-frost group-hover:text-charcoal' => ! $active && ! $onDark,
    ]); ?>">
        <?php echo e($label); ?>

    </span>
</a>
<?php /**PATH C:\Users\User\event-pulse\resources\views\components\category-circle.blade.php ENDPATH**/ ?>