<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['category']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['category']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $accent = match ($category) {
        'music' => 'bg-coral-muted text-coral',
        'tech', 'conference' => 'bg-violet-muted text-violet',
        'sport' => 'bg-coral text-white',
        'art' => 'bg-violet-muted text-violet',
        default => 'bg-cream text-frost border border-charcoal/10',
    };
    $label = \App\Models\Event::CATEGORIES[$category] ?? 'Autre';
?>

<span <?php echo e($attributes->merge(['class' => "inline-flex items-center px-3 py-1 rounded-lg text-xs font-semibold {$accent}"])); ?>>
    <?php echo e($label); ?>

</span>
<?php /**PATH C:\Users\User\event-pulse\resources\views\components\category-badge.blade.php ENDPATH**/ ?>