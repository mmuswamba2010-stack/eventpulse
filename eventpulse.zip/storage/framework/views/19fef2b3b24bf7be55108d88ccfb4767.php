<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'ep-btn'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\User\event-pulse\resources\views\components\primary-button.blade.php ENDPATH**/ ?>