<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'selected' => false,
    'name' => 'mobile_provider',
    'value',
    'label',
    'logo',
    'compact' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'selected' => false,
    'name' => 'mobile_provider',
    'value',
    'label',
    'logo',
    'compact' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<label <?php echo e($attributes->class([
    'group relative flex cursor-pointer items-center justify-center border-2 rounded-xl bg-white text-center select-none transition',
    'flex-col gap-1.5 px-2 py-2' => $compact,
    'flex-col gap-2 px-2 py-3' => ! $compact,
    'border-brand bg-brand-50 ring-2 ring-brand/20' => $selected,
    'border-slate-200 hover:border-slate-300' => ! $selected,
])); ?>

    onclick="
        const root = this.closest('[data-mobile-providers]');
        root.querySelectorAll('label').forEach(l => {
            l.classList.remove('border-brand','bg-brand-50','ring-2','ring-brand/20');
            l.classList.add('border-slate-200');
            const t = l.querySelector('[data-provider-label]');
            if (t) { t.classList.remove('text-brand-700'); t.classList.add('text-slate-700'); }
        });
        this.classList.add('border-brand','bg-brand-50','ring-2','ring-brand/20');
        this.classList.remove('border-slate-200');
        const label = this.querySelector('[data-provider-label]');
        if (label) { label.classList.add('text-brand-700'); label.classList.remove('text-slate-700'); }
    ">
    <input type="radio" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>" class="sr-only" <?php if($selected): echo 'checked'; endif; ?>>
    <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'flex items-center justify-center rounded-lg bg-white',
        'h-8 w-full px-1' => $compact,
        'h-16 w-full px-2 rounded-xl' => ! $compact,
    ]); ?>">
        <img src="<?php echo e(asset('images/payments/'.$logo)); ?>" alt="<?php echo e($label); ?>"
             class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                 'max-w-full object-contain',
                 'max-h-6' => $compact,
                 'max-h-14' => ! $compact,
             ]); ?>"
             loading="lazy">
    </span>
    <?php if (! ($compact)): ?>
        <span data-provider-label class="text-[11px] font-bold leading-tight <?php echo e($selected ? 'text-brand-700' : 'text-slate-700'); ?>">
            <?php echo e($label); ?>

        </span>
    <?php endif; ?>
</label>
<?php /**PATH C:\Users\User\event-pulse\resources\views/components/mobile-money-provider.blade.php ENDPATH**/ ?>