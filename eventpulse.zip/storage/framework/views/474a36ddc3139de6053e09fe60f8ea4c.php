<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="description" content="Event Pulse — billetterie en ligne, QR Code et gestion d'événements.">

        <title><?php echo e(config('app.name', 'Event Pulse')); ?></title>

        <link rel="icon" href="<?php echo e(asset('images/brand/mark.svg')); ?>" type="image/svg+xml">
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=space-grotesk:500,600,700|inter:400,500,600,700&display=swap" rel="stylesheet" />

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="font-sans antialiased bg-white">
        <div class="min-h-screen flex flex-col">
            <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php if(session('success') || session('error')): ?>
                <div class="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 mt-6">
                    <?php if(session('success')): ?>
                        <div class="flex items-center gap-3 ep-card px-5 py-3.5 text-sm font-medium text-charcoal border-l-4 border-l-violet">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="flex items-center gap-3 ep-card px-5 py-3.5 text-sm font-medium text-coral border-l-4 border-l-coral">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if(isset($header)): ?>
                <div class="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-8">
                    <?php echo e($header); ?>

                </div>
            <?php endif; ?>

            <main class="flex-1">
                <?php echo e($slot); ?>

            </main>

            <footer id="about" class="mt-auto bg-charcoal text-white">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">
                        <div class="lg:col-span-1">
                            <?php if (isset($component)) { $__componentOriginal8741a05e11b0c77d19ec61b6b35b26b3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8741a05e11b0c77d19ec61b6b35b26b3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.brand-logo','data' => ['tone' => 'light','variant' => 'full','class' => 'shrink-0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('brand-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['tone' => 'light','variant' => 'full','class' => 'shrink-0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8741a05e11b0c77d19ec61b6b35b26b3)): ?>
<?php $attributes = $__attributesOriginal8741a05e11b0c77d19ec61b6b35b26b3; ?>
<?php unset($__attributesOriginal8741a05e11b0c77d19ec61b6b35b26b3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8741a05e11b0c77d19ec61b6b35b26b3)): ?>
<?php $component = $__componentOriginal8741a05e11b0c77d19ec61b6b35b26b3; ?>
<?php unset($__componentOriginal8741a05e11b0c77d19ec61b6b35b26b3); ?>
<?php endif; ?>
                            <p class="mt-4 text-sm text-white/60 leading-relaxed max-w-xs">
                                Billetterie en ligne, QR code et scan à l'entrée — réservez vos événements en toute simplicité.
                            </p>
                        </div>

                        <div>
                            <p class="text-sm font-semibold text-white mb-4">Navigation</p>
                            <ul class="space-y-2.5 text-sm text-white/60">
                                <li><a href="<?php echo e(route('events.index')); ?>" class="hover:text-white no-underline transition">Accueil</a></li>
                                <li><a href="<?php echo e(route('events.index')); ?>#events" class="hover:text-white no-underline transition">Événements</a></li>
                                <li><a href="<?php echo e(route('events.index')); ?>#categories" class="hover:text-white no-underline transition">Catégories</a></li>
                                <?php if(auth()->guard()->check()): ?>
                                    <li><a href="<?php echo e(route('tickets.index')); ?>" class="hover:text-white no-underline transition">Mes billets</a></li>
                                <?php else: ?>
                                    <li><a href="<?php echo e(route('login')); ?>" class="hover:text-white no-underline transition">Connexion</a></li>
                                <?php endif; ?>
                            </ul>
                        </div>

                        <div>
                            <p class="text-sm font-semibold text-white mb-4">Informations</p>
                            <ul class="space-y-2.5 text-sm text-white/60">
                                <li><a href="<?php echo e(route('register')); ?>" class="hover:text-white no-underline transition">Devenir organisateur</a></li>
                                <li><a href="<?php echo e(route('events.index')); ?>#about" class="hover:text-white no-underline transition">À propos</a></li>
                                <li><span class="text-white/40">Support 24/7</span></li>
                            </ul>
                        </div>

                        <div id="newsletter">
                            <p class="text-sm font-semibold text-white mb-4">Restez informé</p>
                            <p class="text-sm text-white/60 mb-3">Recevez les prochains événements directement dans votre boîte mail.</p>
                            <form method="POST" action="<?php echo e(route('newsletter.subscribe')); ?>" class="space-y-2">
                                <?php echo csrf_field(); ?>
                                <div class="flex gap-2">
                                    <label for="footer-email" class="sr-only">E-mail</label>
                                    <input id="footer-email" type="email" name="email" required
                                           value="<?php echo e(old('email')); ?>"
                                           placeholder="votre@email.com"
                                           class="flex-1 min-w-0 rounded-lg border-0 bg-white/10 px-3 py-2.5 text-sm text-white placeholder:text-white/40 focus:ring-2 focus:ring-coral/50">
                                    <button type="submit" class="inline-flex items-center justify-center rounded-lg bg-coral px-3.5 py-2.5 text-white hover:bg-coral-soft transition" aria-label="S'inscrire">
                                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-right','class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'w-4 h-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                                    </button>
                                </div>
                                <?php if(session('newsletter_success')): ?>
                                    <p class="text-xs text-emerald-300"><?php echo e(session('newsletter_success')); ?></p>
                                <?php endif; ?>
                                <?php if(session('newsletter_info')): ?>
                                    <p class="text-xs text-white/70"><?php echo e(session('newsletter_info')); ?></p>
                                <?php endif; ?>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-xs text-coral-soft"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </form>
                        </div>
                    </div>

                    <div class="mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-white/40">
                        <p>&copy; <?php echo e(now()->year); ?> Event Pulse. Tous droits réservés.</p>
                        <p>Conçu avec soin pour l'événementiel.</p>
                    </div>
                </div>
            </footer>
        </div>
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\Users\User\event-pulse\resources\views/layouts/app.blade.php ENDPATH**/ ?>